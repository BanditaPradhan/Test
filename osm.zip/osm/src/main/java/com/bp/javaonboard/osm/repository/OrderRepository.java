package com.bp.javaonboard.osm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.bp.javaonboard.osm.entity.Account;
import com.bp.javaonboard.osm.entity.Order;
import com.bp.javaonboard.osm.entity.OrderDetail;


@Repository
public interface OrderRepository extends JpaRepository<Order, String>{
   
	@Query(value="select o.order_id, o.order_hist_id, o.user_name,o.task_id, o.order_source, o.order_type, o.order_state,o.state, "
			+ "o.reference_number,o.priority, o.name_space,o.version,o.expected_start_date, o.expected_duration, o.expected_completion_date,"
			+ "o.account_id\r\n"
			+ "from  order o , account acct\r\n"
			+ "where o.account_id = acct.account_id\r\n"
			+ "and o.order_id = :orderId", nativeQuery=true)
	public List<OrderDetail> getOrderDetail(@Param("orderId") String orderId);
    
	public List<Order> findByAccountAccountId(String id);
}
